package com;

public class User {
	public static int cid;

	public static int getcid() {
		return cid;
	}

	public static void setcid(int cid) {
	cid = cid;
	}

	

	
}
