package com;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

/**
 * Servlet implementation class epreg
 */
@MultipartConfig(maxFileSize = 16177215)
public class cusreg extends HttpServlet {
    private static final long serialVersionUID = 1L;
       
    public cusreg() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.getWriter().append("Served at: ").append(request.getContextPath());
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
        Connection con = DbConnection.connect();
        InputStream inputStream = null;
        Part filePart = null;
        int cid = 0;
        PreparedStatement st;
        
        try {
            String name = request.getParameter("Name");
            String Email = request.getParameter("email");
            String password = request.getParameter("pass");
            String number = request.getParameter("number");
            String address = request.getParameter("add");
            String message = request.getParameter("message");
            filePart = request.getPart("image");
            
            st = con.prepareStatement("insert into customer values(?,?,?,?,?,?,?,?,?)");
            st.setInt(1, cid);
            st.setString(2, name);
            st.setString(3, Email);
            st.setString(4, password);
            st.setString(5, number);
            st.setString(6, address);
            st.setString(7, message);
            inputStream = filePart.getInputStream();
            st.setBinaryStream(8, inputStream, inputStream.available());
            st.setString(9, "pending");

            int i = st.executeUpdate();
            if (i > 0) { 
                response.sendRedirect("index.html");
            } else {
                response.sendRedirect("index.html");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
