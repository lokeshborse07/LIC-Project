package com;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

/**
 * Servlet implementation class epreg
 */
@MultipartConfig(maxFileSize = 16177215)
public class comreg extends HttpServlet {
    private static final long serialVersionUID = 1L;
       
    public comreg() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.getWriter().append("Served at: ").append(request.getContextPath());
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
        Connection con = DbConnection.connect();
        InputStream inputStream = null;
        Part filePart = null;
        int cid = 0;
        PreparedStatement st;
        
        try {
            String Name = request.getParameter("name");
            String Email = request.getParameter("email");
            String pass = request.getParameter("pass");
            String Phone = request.getParameter("number");
            String Address = request.getParameter("add");
            
            st = con.prepareStatement("insert into company values(?,?,?,?,?,?,?)");
            st.setInt(1, cid);
            st.setString(2, Name);
            st.setString(3, Email);
            st.setString(4, pass);
            st.setString(5, Phone);
            st.setString(6, Address);
            st.setString(7, "pending");
            
            int i = st.executeUpdate();
            if (i > 0) { 
                response.sendRedirect("index.html");
            } else {
                response.sendRedirect("comreg.html");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
