package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbConnection {
    public static Connection connect() {
        Connection con = null;
        try {
            // For MySQL 8+, use the following driver class name
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("Driver loaded");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/visioner", "root", "");
            System.out.println("Connection Established");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return con;
    }
}
