package com;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class pay
 */
public class pay extends HttpServlet {
    private static final long serialVersionUID = 1L;
       
    public pay() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.getWriter().append("Served at: ").append(request.getContextPath());
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
        Connection con = DbConnection.connect();
        int gid = 0;
        PreparedStatement st;

        try {
            String card = request.getParameter("payment_method");
            String upi = request.getParameter("UPI");
            String card_name = request.getParameter("card_number");
            String Name = request.getParameter("card_holder");
            String ExDate = request.getParameter("expiry_date");
            int CVV = Integer.parseInt(request.getParameter("cvv"));
            int Amount = Integer.parseInt(request.getParameter("amount"));

            st = con.prepareStatement("INSERT INTO payment VALUES(?,?,?,?,?,?,?,?,?)");
            st.setInt(1, gid);
            st.setString(2, card);
            st.setString(3, upi);
            st.setString(4, card_name);
            st.setString(5, Name);
            st.setString(6, ExDate);
            st.setInt(7, CVV);
            st.setInt(8, Amount);
            st.setString(9, "pending");

            int i = st.executeUpdate();
            if (i > 0) { 
                response.sendRedirect("pins.html");
            } else {
                response.sendRedirect("payment.html");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
